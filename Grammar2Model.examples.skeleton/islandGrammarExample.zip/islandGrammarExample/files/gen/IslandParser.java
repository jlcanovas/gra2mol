// $ANTLR 3.2 Sep 23, 2009 12:02:23 Island.g 2010-06-15 17:50:22

	import gts.modernization.model.CST.impl.*;
	import gts.modernization.model.CST.*;
	import java.util.Iterator;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import org.antlr.stringtemplate.*;
import org.antlr.stringtemplate.language.*;
import java.util.HashMap;
public class IslandParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "DQUOTE", "ID", "WS"
    };
    public static final int DQUOTE=4;
    public static final int WS=6;
    public static final int ID=5;
    public static final int EOF=-1;

    // delegates
    // delegators


        public IslandParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public IslandParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected StringTemplateGroup templateLib =
      new StringTemplateGroup("IslandParserTemplates", AngleBracketTemplateLexer.class);

    public void setTemplateLib(StringTemplateGroup templateLib) {
      this.templateLib = templateLib;
    }
    public StringTemplateGroup getTemplateLib() {
      return templateLib;
    }
    /** allows convenient multi-value initialization:
     *  "new STAttrMap().put(...).put(...)"
     */
    public static class STAttrMap extends HashMap {
      public STAttrMap put(String attrName, Object value) {
        super.put(attrName, value);
        return this;
      }
      public STAttrMap put(String attrName, int value) {
        super.put(attrName, new Integer(value));
        return this;
      }
    }

    public String[] getTokenNames() { return IslandParser.tokenNames; }
    public String getGrammarFileName() { return "Island.g"; }


    public static class mainRule_return extends ParserRuleReturnScope {
        public Node returnNode;
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start "mainRule"
    // Island.g:18:1: mainRule returns [Node returnNode] : DQUOTEGen= DQUOTE lineStringGen+= lineString DQUOTEGen_1= DQUOTE ;
    public final IslandParser.mainRule_return mainRule() throws RecognitionException {
        IslandParser.mainRule_return retval = new IslandParser.mainRule_return();
        retval.start = input.LT(1);

        Token DQUOTEGen=null;
        Token DQUOTEGen_1=null;
        List list_lineStringGen=null;
        RuleReturnScope lineStringGen = null;
        try {
            // Island.g:19:1: (DQUOTEGen= DQUOTE lineStringGen+= lineString DQUOTEGen_1= DQUOTE )
            // Island.g:20:3: DQUOTEGen= DQUOTE lineStringGen+= lineString DQUOTEGen_1= DQUOTE
            {
            DQUOTEGen=(Token)match(input,DQUOTE,FOLLOW_DQUOTE_in_mainRule46); if (state.failed) return retval;
            pushFollow(FOLLOW_lineString_in_mainRule51);
            lineStringGen=lineString();

            state._fsp--;
            if (state.failed) return retval;
            if (list_lineStringGen==null) list_lineStringGen=new ArrayList();
            list_lineStringGen.add(lineStringGen);

            DQUOTEGen_1=(Token)match(input,DQUOTE,FOLLOW_DQUOTE_in_mainRule56); if (state.failed) return retval;
            if ( state.backtracking==0 ) {

              		// Create return CST Node
              		Node mainRuleReturnNode = CSTFactoryImpl.eINSTANCE.createNode();
              		mainRuleReturnNode.setKind("mainRule");
              	    // Create a CST Leaf
              		if(DQUOTEGen != null) {
              			Leaf DQUOTEGenLeaf = CSTFactoryImpl.eINSTANCE.createLeaf("DQUOTE", (DQUOTEGen!=null?DQUOTEGen.getText():null), DQUOTEGen.getCharPositionInLine(), DQUOTEGen.getLine());
              			mainRuleReturnNode.getChildren().add(DQUOTEGenLeaf);
              		}
              	    // Create a CST Node
              		if(list_lineStringGen != null) {
              	        for(Iterator it = list_lineStringGen.iterator(); it.hasNext(); )  { 
              	            IslandParser.lineString_return r = (IslandParser.lineString_return) it.next(); 
              	            if(r != null && r.returnNode != null) {
              	            	r.returnNode.setKind("lineString");
              	            	mainRuleReturnNode.getChildren().add(r.returnNode);
              	            } 
              	        }
              	    }
              	    // Create a CST Leaf
              		if(DQUOTEGen_1 != null) {
              			Leaf DQUOTEGen_1Leaf = CSTFactoryImpl.eINSTANCE.createLeaf("DQUOTE", (DQUOTEGen_1!=null?DQUOTEGen_1.getText():null), DQUOTEGen_1.getCharPositionInLine(), DQUOTEGen_1.getLine());
              			mainRuleReturnNode.getChildren().add(DQUOTEGen_1Leaf);
              		}
              		// Returns the Node with CST Leaves/Nodes
              		retval.returnNode = mainRuleReturnNode;
              	
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "mainRule"

    public static class lineString_return extends ParserRuleReturnScope {
        public Node returnNode;
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start "lineString"
    // Island.g:50:1: lineString returns [Node returnNode] : IDGen= ID ;
    public final IslandParser.lineString_return lineString() throws RecognitionException {
        IslandParser.lineString_return retval = new IslandParser.lineString_return();
        retval.start = input.LT(1);

        Token IDGen=null;

        try {
            // Island.g:51:1: (IDGen= ID )
            // Island.g:51:4: IDGen= ID
            {
            IDGen=(Token)match(input,ID,FOLLOW_ID_in_lineString78); if (state.failed) return retval;
            if ( state.backtracking==0 ) {

              		// Create return CST Node
              		Node lineStringReturnNode = CSTFactoryImpl.eINSTANCE.createNode();
              		lineStringReturnNode.setKind("lineString");
              	    // Create a CST Leaf
              		if(IDGen != null) {
              			Leaf IDGenLeaf = CSTFactoryImpl.eINSTANCE.createLeaf("ID", (IDGen!=null?IDGen.getText():null), IDGen.getCharPositionInLine(), IDGen.getLine());
              			lineStringReturnNode.getChildren().add(IDGenLeaf);
              		}
              		// Returns the Node with CST Leaves/Nodes
              		retval.returnNode = lineStringReturnNode;
              	
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "lineString"

    // Delegated rules


 

    public static final BitSet FOLLOW_DQUOTE_in_mainRule46 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_lineString_in_mainRule51 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_DQUOTE_in_mainRule56 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_lineString78 = new BitSet(new long[]{0x0000000000000002L});

}